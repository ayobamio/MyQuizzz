package com.example.myquiz;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class QuestionBank {

    List<Question>list = new ArrayList<>();
    MyDataBaseHelper myDataBaseHelper;
    public int getLength(){return list.size();}


    public  String getQuestion(int a ){return  list.get(a).getQuestion(); }

    public  String getChoice(int index, int num){ return  list.get(index).getChoice(num-1);}

    public  String getCorrectAnswer(int a){return list.get(a).getAnswer();}


    public  void initQuestions(Context context){
        myDataBaseHelper= new MyDataBaseHelper(context);
        list= myDataBaseHelper.getAllQuestionsList();

        if(list.isEmpty()){
            myDataBaseHelper.addInitialQuestion(new Question("1. When did google acquire Android?", new String[]{"2001","2001","2004","2005"}, "2005"));

            myDataBaseHelper.addInitialQuestion(new Question("2. When did google acquire Apple?", new String[]{"2001","2001","2004","2005"}, "2007"));

            myDataBaseHelper.addInitialQuestion(new Question("3. When did google acquire Android?", new String[]{"2001","2001","2004","2005"}, "2005"));

            myDataBaseHelper.addInitialQuestion(new Question("4. When did google acquire Android?", new String[]{"2001","2001","2004","2005"}, "2005"));

            list = myDataBaseHelper.getAllQuestionsList();
        }

    }
}
